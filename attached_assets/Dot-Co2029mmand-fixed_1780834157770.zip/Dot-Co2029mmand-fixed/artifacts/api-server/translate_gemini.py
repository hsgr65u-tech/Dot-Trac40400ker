#!/usr/bin/env python3
import sys
import json
import asyncio
import re

def extract_cookies(cookies_path: str) -> dict:
    wanted = {
        "__Secure-1PSID": None,
        "__Secure-1PSIDTS": None,
        "__Secure-1PSIDCC": None,
        "__Secure-3PSID": None,
        "SAPISID": None,
        "APISID": None,
        "HSID": None,
        "SSID": None,
        "SID": None,
    }
    try:
        with open(cookies_path, "r", encoding="utf-8") as f:
            for line in f:
                line = line.strip()
                if not line or line.startswith("#"):
                    continue
                parts = line.split("\t")
                if len(parts) >= 7:
                    name = parts[5]
                    value = parts[6]
                    if name in wanted:
                        wanted[name] = value
    except Exception as e:
        pass
    return {k: v for k, v in wanted.items() if v}

async def translate(cookies_path: str, text: str) -> str:
    from gemini_webapi import GeminiClient

    cookies = extract_cookies(cookies_path)
    psid = cookies.get("__Secure-1PSID")
    psidts = cookies.get("__Secure-1PSIDTS")

    if not psid:
        raise ValueError("لم يتم العثور على __Secure-1PSID في ملف الكوكيز")

    client = GeminiClient(
        secure_1psid=psid,
        secure_1psidts=psidts or "",
    )
    await client.init(timeout=30, auto_close=False, close_delay=300, auto_refresh=False)

    prompt = (
        "Translate the following text to Arabic professionally. "
        "Understand the context and meaning. "
        "Return ONLY the Arabic translation, nothing else.\n\n"
        f"Text:\n{text}"
    )

    response = await client.generate_content(prompt)
    await client.close()
    return response.text.strip()

if __name__ == "__main__":
    if len(sys.argv) < 3:
        print(json.dumps({"error": "Usage: translate_gemini.py <cookies_path> <text>"}))
        sys.exit(1)

    cookies_path = sys.argv[1]
    text = sys.argv[2]

    try:
        result = asyncio.run(translate(cookies_path, text))
        print(json.dumps({"translation": result}))
    except Exception as e:
        print(json.dumps({"error": str(e)}))
        sys.exit(1)
